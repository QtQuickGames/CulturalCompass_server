# HackhatonNGO
Aplikacja do wyszukiwania NGO budowana na Hackhaton 2023 Płock
